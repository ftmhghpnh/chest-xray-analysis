import os
import tensorflow as tf
import tensorflow.contrib.eager as tfe
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

tf.enable_eager_execution()

base_path = '/home/fateme/CheXpert-v1.0-small'
train_table = pd.read_csv(os.path.join(base_path, 'train.csv'))
case_array = ['Atelectasis', 'Cardiomegaly', 'Consolidation', 'Edema', 'Pleural Effusion']

device = "gpu:0" if tfe.num_gpus() else "cpu:0"

batch_size = 64        # You will play around with this 
n_epochs = 100         # Choose num epochs based on when you think the parameters have converged
learning_rate = 0.0001 # You will try different learning rates

train_loss_history = []

class XceptionClassifier(tf.keras.Model):
    
    def __init__(self, n_classes):
        super(XceptionClassifier, self).__init__()
        # Define the layer(s) you would like to use for your classifier
        self.dense_layer = tf.keras.layers.Dense(units=n_classes)
        
    def call(self, inputs):
        # Set this up appropriately, will depend on how many layers you choose
        result = self.dense_layer(inputs)
        
        return result
    
    
# run this once for all models, in order to have same shuffeled data_set for all of them.
data = np.load(os.path.join(base_path, 'bottle_neck.npz'))
X_train, index_train = data['bottle_necks'],  data['indexes']

X_train, X_val, index_train, index_val = train_test_split(X_train, index_train, test_size=0.2, random_state=40)

Y_train = train_table.loc[index_train, case_array].values
Y_train[Y_train == -1] = 0
Y_train[np.isnan(Y_train)] = -1
Y_val = train_table.loc[index_val, case_array].values
Y_val[Y_val == -1] = 0
Y_val[np.isnan(Y_val)] = -1

train_features_dataset = tf.data.Dataset.from_tensor_slices(X_train)
train_label_dataset = tf.data.Dataset.from_tensor_slices(Y_train)
train_dataset = tf.data.Dataset.zip((train_features_dataset, train_label_dataset))
train_dataset = train_dataset.batch(batch_size) 

x_classifier = XceptionClassifier(n_classes=len(case_array))
optimizer = tf.train.AdamOptimizer(learning_rate) 

with tf.device(device):
    for epoch in range(n_epochs):
        for batch, (features, labels) in enumerate(train_dataset):

            with tf.GradientTape() as tape:
                # Compute logits
                logits = x_classifier(features)
                mask = tf.math.logical_not(tf.equal(labels, -1))
                xe_loss = tf.reduce_mean(tf.losses.sigmoid_cross_entropy(multi_class_labels=labels, logits=logits, weights=mask))

            train_loss_history.append(xe_loss.numpy())
            # Compute gradient and apply gradients
            grads = tape.gradient(xe_loss, x_classifier.variables)
            optimizer.apply_gradients(zip(grads, x_classifier.variables),
                                      global_step=tf.train.get_or_create_global_step())
            
            if batch % 100 == 0:
                print('\rEpoch: {}, Batch: {}, Loss: {}'.format(epoch, batch, train_loss_history[-1]), end='')

fig = plt.figure()
fig.set_figwidth(fig.get_figwidth() * 3)
fig.set_figheight(fig.get_figheight() )

plt.plot(train_loss_history)
plt.ylabel('$\mathcal{L}(W)$', fontsize=14)
plt.xlabel('Iterations', fontsize=14)
plt.title('Train Loss Curve')
plt.savefig(os.path.join(base_path, 'train_loss_per_iteration'))