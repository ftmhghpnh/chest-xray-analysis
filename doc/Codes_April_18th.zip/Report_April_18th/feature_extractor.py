import pandas as pd
import os
import tensorflow as tf
from tensorflow.keras.applications import Xception
from tensorflow.keras.layers import GlobalAveragePooling2D
import tensorflow.contrib.eager as tfe
import numpy as np

tf.enable_eager_execution()

very_base_path = '/home/fateme'
base_path = os.path.join(very_base_path, 'CheXpert-v1.0-small')
train_table = pd.read_csv(os.path.join(base_path, 'train.csv'))

case_array = ['Atelectasis', 'Cardiomegaly', 'Consolidation', 'Edema', 'Pleural Effusion']
ans = [-1, 1]

def create_dataset_images(file_paths):
    # Reads an image from a file, decodes it into a dense tensor, and resizes it
    # to a fixed shape. Read more here: https://www.tensorflow.org/guide/datasets#decoding_image_data_and_resizing_it
    def _parse_function(filename):
        image_string = tf.read_file(filename)
        image_decoded = tf.image.decode_jpeg(image_string, channels=3)
        image_resized = tf.image.resize_images(image_decoded, [200, 200])
        return image_resized

    file_paths = tf.constant(file_paths)
    
    dataset = tf.data.Dataset.from_tensor_slices((file_paths))
    dataset = dataset.map(_parse_function)

    return dataset

class XceptionBottleneck(tf.keras.Model):
    
    def __init__(self):
        super(XceptionBottleneck, self).__init__()
        
        # Define xception layer (include_top=False and use imagenet weights), 
        # see: https://keras.io/applications/#models-for-image-classification-with-weights-trained-on-imagenet
        self.xception_layers = Xception(weights='imagenet', include_top=False)
        
        # Define pooling GlobalAveragePooling2D 
        # see: https://keras.io/layers/pooling/  
        self.pooling_layer = GlobalAveragePooling2D()
        
    def call(self, inputs):
        result = self.xception_layers(inputs)
        result = self.pooling_layer(result)
        return result

def cache_bottleneck_layers(file_paths, batch_size, device):

    bottle_necks = []
    dataset = create_dataset_images(file_paths).batch(batch_size)
    n_samples = len(file_paths)

    device = "gpu:0" if tfe.num_gpus() else "cpu:0"
    
    with tf.device(device):
        xception_out = XceptionBottleneck()
        for batch_num, image in enumerate(dataset):
            print('\rComputing bottle neck layers... batch {} of {}'.format(batch_num+1, n_samples//batch_size), end="")
            
            # Compute bottle necks layer for image batch convert to numpy and append to bottle_necks
            # ...
            # ...
            result = xception_out(image)
            result = result.numpy()
            bottle_necks.append(result)
            
    return np.vstack(bottle_necks)

train_selected = train_table.loc[(train_table[case_array[0]].isin(ans) | train_table[case_array[1]].isin(ans) | train_table[case_array[2]].isin(ans) | train_table[case_array[3]].isin(ans) | train_table[case_array[4]].isin(ans))]
train_file_paths = [os.path.join(very_base_path, path) for path in train_selected['Path'].tolist()]

device = "gpu:0" if tfe.num_gpus() else "cpu:0"
bottle_necks = cache_bottleneck_layers(train_file_paths, batch_size=64, device=device)
np.savez(os.path.join(base_path, 'bottle_neck.npz'), bottle_necks=bottle_necks, indexes=train_selected.index.values)
